from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, ForeignKey, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_active = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    progress = relationship("UserProgress", back_populates="user")
    achievements = relationship("UserAchievement", back_populates="user")
    code_submissions = relationship("CodeSubmission", back_populates="user")
    shared_solutions = relationship("SharedSolution", back_populates="user")

class UserProgress(Base):
    __tablename__ = 'user_progress'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    item_id = Column(String(100), nullable=False)  # tutorial_id or exercise_id
    item_type = Column(String(20), nullable=False)  # 'tutorial' or 'exercise'
    category = Column(String(50), nullable=False)
    completed_at = Column(DateTime, default=datetime.utcnow)
    time_spent = Column(Integer)  # seconds
    attempts = Column(Integer, default=1)
    
    # Relationships
    user = relationship("User", back_populates="progress")

class UserAchievement(Base):
    __tablename__ = 'user_achievements'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    achievement_id = Column(String(100), nullable=False)
    achievement_title = Column(String(200), nullable=False)
    earned_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="achievements")

class CodeSubmission(Base):
    __tablename__ = 'code_submissions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    exercise_id = Column(String(100), nullable=False)
    code = Column(Text, nullable=False)
    is_correct = Column(Boolean, nullable=False)
    submitted_at = Column(DateTime, default=datetime.utcnow)
    execution_time = Column(Float)  # seconds
    error_message = Column(Text)
    
    # Relationships
    user = relationship("User", back_populates="code_submissions")

class SharedSolution(Base):
    __tablename__ = 'shared_solutions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    exercise_id = Column(String(100), nullable=False)
    title = Column(String(200), nullable=False)
    code = Column(Text, nullable=False)
    description = Column(Text)
    likes = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_public = Column(Boolean, default=True)
    
    # Relationships
    user = relationship("User", back_populates="shared_solutions")

class LearningSession(Base):
    __tablename__ = 'learning_sessions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    session_start = Column(DateTime, default=datetime.utcnow)
    session_end = Column(DateTime)
    activities_count = Column(Integer, default=0)
    exercises_completed = Column(Integer, default=0)
    tutorials_completed = Column(Integer, default=0)

class ExerciseStats(Base):
    __tablename__ = 'exercise_stats'
    
    id = Column(Integer, primary_key=True)
    exercise_id = Column(String(100), unique=True, nullable=False)
    total_attempts = Column(Integer, default=0)
    successful_completions = Column(Integer, default=0)
    average_time = Column(Float, default=0.0)
    difficulty_rating = Column(Float, default=0.0)
    common_errors = Column(Text)  # JSON string of common error patterns
    last_updated = Column(DateTime, default=datetime.utcnow)